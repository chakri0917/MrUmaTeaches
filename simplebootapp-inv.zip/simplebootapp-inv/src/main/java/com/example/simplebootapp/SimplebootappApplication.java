package com.example.simplebootapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplebootappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimplebootappApplication.class, args);
	}

}
